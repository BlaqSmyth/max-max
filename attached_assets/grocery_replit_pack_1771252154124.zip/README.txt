Replit Grocery Product Pack

Contents
- products.csv / products.json  Product data with image paths
- images/                       1024x1024 PNG packshots (generated placeholders)

How to use (Node/Express)
1) Upload and unzip in Replit.
2) Serve images as static assets:
   app.use('/images', express.static('images'))

3) In your frontend, use the 'image' field from products.json/csv.
   Example: <img src={"/" + product.image} />

Notes
- These images are clean generated packshots so your UI stops showing "No Image Available".
- If you later want real web-sourced photos, I can map each product to a verified source URL list
  that your app can fetch at build time (depending on allowed sources).
